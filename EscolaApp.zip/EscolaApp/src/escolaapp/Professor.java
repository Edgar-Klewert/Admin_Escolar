/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package escolaapp;

/**
 *
 * @author hz14m
 */
public class Professor extends Pessoa {
    private int dataContratacao;
    private String disciplina;

    public Professor(String nome, int id, int dataContratacao, String disciplina) {
        super(nome, id);
        this.dataContratacao = dataContratacao;
        this.disciplina = disciplina;
    }
    
    public int getdataContratacao() {
        return dataContratacao;
    }
    
    public String getDisciplina() {
        return disciplina;
    }
    
}