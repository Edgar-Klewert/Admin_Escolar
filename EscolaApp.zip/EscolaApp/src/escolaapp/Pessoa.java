/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package escolaapp;

/**
 *
 * @author hz14m
 */
import java.io.Serializable;

public class Pessoa implements Serializable {
    protected String nome;
    protected int id;

    public Pessoa(String nome, int id) {
        this.nome = nome;
        this.id = id;
    }
    
    public String getNome() {
        return nome;
    }
    
    public int getId() {
        return id;
    }
}