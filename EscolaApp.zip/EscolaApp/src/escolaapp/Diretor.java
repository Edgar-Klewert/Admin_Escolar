/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package escolaapp;

/**
 *
 * @author hz14m
 */
public class Diretor extends Pessoa {
    private int dataContratacao;

    public Diretor(String nome, int id, int dataContratacao) {
        super(nome, id);
        this.dataContratacao = dataContratacao;
    }
    
    public int getdataContratacao() {
        return dataContratacao;
    }
}